#include<stdio.h>
int main()
{
	float r,a;
	printf("enter r\n");
	scanf("%f",&r);
	a=(3.14)*r*r;
	printf("area is = %f",a);
}
