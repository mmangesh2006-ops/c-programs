#include<stdio.h>
#include<string.h>
int main()
{
	char st[30];
	printf("enter string :");
	gets(st);
	printf("len=%d",strlen(st));
	return 0;
}
